﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToBeLifeBetter.Service.Entity
{
    public class CityEntity: BaseEntity
    {
        public string Name { get; set; }
    }
}
